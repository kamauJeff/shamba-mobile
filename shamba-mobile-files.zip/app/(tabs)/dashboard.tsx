import { useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  RefreshControl, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { useAuthStore } from '../../src/store/auth.store';
import { walletApi, loansApi, weatherApi } from '../../src/api/client';
import { useTheme } from '../../src/lib/theme';

function ScreenHeader({ name, theme }: { name: string; theme: any }) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <View style={{ backgroundColor: theme.colors.header, padding: 16, paddingTop: 52, paddingBottom: 22 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12 }}>{greeting}</Text>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginTop: 2 }}>{name} 👋</Text>
        </View>
        <TouchableOpacity onPress={() => router.push('/(tabs)/profile')}>
          <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 18 }}>🔔</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function DashboardScreen() {
  const theme = useTheme();
  const { user } = useAuthStore();

  const { data: walletData, isLoading: walletLoading, refetch: refetchWallet } = useQuery({
    queryKey: ['wallet'],
    queryFn: () => walletApi.getBalance().then((r) => r.data),
  });

  const { data: loansData, refetch: refetchLoans } = useQuery({
    queryKey: ['loans'],
    queryFn: () => loansApi.getMyLoans().then((r) => r.data),
  });

  const { data: weatherData, refetch: refetchWeather } = useQuery({
    queryKey: ['weather', user?.county],
    queryFn: () => weatherApi.getCurrent(user?.county || 'Nairobi').then((r) => r.data),
    enabled: !!user?.county,
  });

  const onRefresh = () => {
    refetchWallet();
    refetchLoans();
    refetchWeather();
  };

  const activeLoans = loansData?.loans?.filter((l: any) => l.status === 'ACTIVE') || [];
  const balance = walletData?.balance ?? 0;
  const s = makeStyles(theme);

  return (
    <View style={s.container}>
      <ScreenHeader name={user?.name?.split(' ')[0] || 'Mkulima'} theme={theme} />

      <ScrollView
        style={s.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={false} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
      >
        {/* Wallet card */}
        <View style={s.walletCard}>
          <Text style={s.walletLabel}>Shamba Wallet</Text>
          {walletLoading
            ? <ActivityIndicator color="#fff" style={{ marginVertical: 6 }} />
            : <Text style={s.walletAmount}>KES {balance.toLocaleString()}</Text>
          }
          <View style={s.walletMeta}>
            <Text style={s.walletMetaText}>{user?.phone}</Text>
            <Text style={s.walletMetaText}>{user?.role === 'FARMER' ? '🌾 Farmer' : '🛒 Buyer'}</Text>
          </View>
        </View>

        {/* Quick actions */}
        <View style={s.sectionRow}>
          {[
            { icon: '📤', label: 'Send' },
            { icon: '📥', label: 'Receive' },
            { icon: '🛒', label: 'Market', onPress: () => router.push('/(tabs)/market') },
            { icon: '📋', label: 'Pay Loan', onPress: () => router.push('/(tabs)/loans') },
          ].map((a) => (
            <TouchableOpacity key={a.label} style={s.qaCard} onPress={a.onPress} activeOpacity={0.7}>
              <Text style={s.qaIcon}>{a.icon}</Text>
              <Text style={s.qaLabel}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Stats */}
        <Text style={s.sectionTitle}>Overview</Text>
        <View style={s.statsGrid}>
          <StatCard
            theme={theme}
            label="Credit score"
            value={user?.creditScore?.toString() || '—'}
            sub="Good standing"
            subColor={theme.colors.success}
          />
          <StatCard
            theme={theme}
            label="Active loans"
            value={activeLoans.length.toString()}
            sub={activeLoans.length > 0 ? 'Due soon' : 'All clear'}
            subColor={activeLoans.length > 0 ? theme.colors.warning : theme.colors.success}
          />
          <StatCard
            theme={theme}
            label="Insurance"
            value="Active"
            sub="Crop cover"
            subColor={theme.colors.success}
          />
          <StatCard
            theme={theme}
            label="My groups"
            value="2"
            sub="Kirinyaga Chama"
            subColor={theme.colors.textSecondary}
          />
        </View>

        {/* Weather */}
        <View style={s.weatherCard}>
          <Text style={{ fontSize: 28, marginRight: 12 }}>⛅</Text>
          <View>
            <Text style={s.weatherTemp}>
              {weatherData?.temperature ? `${weatherData.temperature}°C` : '22°C'}
            </Text>
            <Text style={s.weatherDesc}>
              {user?.county || 'Nairobi'} · {weatherData?.condition || 'Partly cloudy'}
            </Text>
          </View>
        </View>

        {/* Active loan alert */}
        {activeLoans.length > 0 && (
          <TouchableOpacity style={s.loanAlert} onPress={() => router.push('/(tabs)/loans')}>
            <Text style={{ fontSize: 18, marginRight: 10 }}>⚠️</Text>
            <Text style={s.loanAlertText}>
              Loan repayment of <Text style={{ fontWeight: '600' }}>KES {activeLoans[0]?.nextRepayment?.toLocaleString() || '2,000'}</Text> due soon
            </Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

function StatCard({ theme, label, value, sub, subColor }: any) {
  return (
    <View style={{
      flex: 1, minWidth: '45%', backgroundColor: theme.colors.cardBg,
      borderRadius: theme.radius.md, padding: 13,
      borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    }}>
      <Text style={{ fontSize: 11, color: theme.colors.textSecondary, marginBottom: 4 }}>{label}</Text>
      <Text style={{ fontSize: 20, fontWeight: '600', color: theme.colors.textPrimary }}>{value}</Text>
      <Text style={{ fontSize: 11, color: subColor, marginTop: 2 }}>{sub}</Text>
    </View>
  );
}

const makeStyles = (theme: ReturnType<typeof import('../../src/lib/theme').useTheme>) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.colors.background },
    scroll: { flex: 1 },

    walletCard: {
      margin: 14,
      borderRadius: theme.radius.lg,
      backgroundColor: theme.colors.primary,
      padding: 20,
    },
    walletLabel: { color: 'rgba(255,255,255,0.75)', fontSize: 12, marginBottom: 4 },
    walletAmount: { color: '#fff', fontSize: 30, fontWeight: '700', letterSpacing: -0.5 },
    walletMeta: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 14 },
    walletMetaText: { color: 'rgba(255,255,255,0.75)', fontSize: 12 },

    sectionRow: {
      flexDirection: 'row', gap: 8, marginHorizontal: 14, marginBottom: 16,
    },
    qaCard: {
      flex: 1, backgroundColor: theme.colors.cardBg, borderRadius: theme.radius.md,
      padding: 12, alignItems: 'center', borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    qaIcon: { fontSize: 22, marginBottom: 4 },
    qaLabel: { fontSize: 10, color: theme.colors.textSecondary, fontWeight: '500' },

    sectionTitle: {
      fontSize: 14, fontWeight: '600', color: theme.colors.textPrimary,
      marginHorizontal: 14, marginBottom: 8,
    },
    statsGrid: {
      flexDirection: 'row', flexWrap: 'wrap', gap: 8,
      marginHorizontal: 14, marginBottom: 14,
    },

    weatherCard: {
      flexDirection: 'row', alignItems: 'center',
      backgroundColor: theme.colors.cardBg, borderRadius: theme.radius.md,
      padding: 14, marginHorizontal: 14, marginBottom: 12,
      borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    weatherTemp: { fontSize: 22, fontWeight: '600', color: theme.colors.textPrimary },
    weatherDesc: { fontSize: 12, color: theme.colors.textSecondary, marginTop: 2 },

    loanAlert: {
      flexDirection: 'row', alignItems: 'center',
      backgroundColor: theme.colors.warningBg, borderRadius: theme.radius.md,
      padding: 13, marginHorizontal: 14, marginBottom: 8,
      borderWidth: 0.5, borderColor: theme.colors.border,
    },
    loanAlertText: { fontSize: 13, color: theme.colors.warningText, flex: 1 },
  });
