import { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Modal, TextInput, Alert, ActivityIndicator,
} from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { loansApi } from '../../src/api/client';
import { useAuthStore } from '../../src/store/auth.store';
import { useTheme } from '../../src/lib/theme';

const SCORE_MIN = 300;
const SCORE_MAX = 850;

function CreditMeter({ score, theme }: { score: number; theme: any }) {
  const pct = ((score - SCORE_MIN) / (SCORE_MAX - SCORE_MIN)) * 100;
  const tier =
    score >= 750 ? { label: 'Excellent', color: theme.colors.success } :
    score >= 670 ? { label: 'Good', color: '#3a9bd5' } :
    score >= 580 ? { label: 'Fair', color: theme.colors.warning } :
    { label: 'Poor', color: theme.colors.danger };

  return (
    <View style={{ backgroundColor: theme.colors.cardBg, borderRadius: theme.radius.lg, padding: 18, margin: 14, marginBottom: 6, borderWidth: 0.5, borderColor: theme.colors.cardBorder }}>
      <Text style={{ fontSize: 12, color: theme.colors.textSecondary, marginBottom: 4 }}>Your credit score</Text>
      <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
        <Text style={{ fontSize: 36, fontWeight: '700', color: tier.color }}>{score}</Text>
        <View style={{ backgroundColor: tier.color + '22', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 3 }}>
          <Text style={{ fontSize: 12, fontWeight: '600', color: tier.color }}>{tier.label}</Text>
        </View>
      </View>
      <View style={{ height: 8, backgroundColor: theme.colors.border, borderRadius: 4, marginTop: 12 }}>
        <View style={{ height: 8, width: `${pct}%`, backgroundColor: tier.color, borderRadius: 4 }} />
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
        <Text style={{ fontSize: 10, color: theme.colors.textMuted }}>300</Text>
        <Text style={{ fontSize: 10, color: theme.colors.textMuted }}>850</Text>
      </View>
    </View>
  );
}

export default function LoansScreen() {
  const theme = useTheme();
  const queryClient = useQueryClient();
  const { user } = useAuthStore();

  const [applyModal, setApplyModal] = useState(false);
  const [repayModal, setRepayModal] = useState<any>(null);
  const [loanForm, setLoanForm] = useState({ amount: '', purpose: '', duration: '3' });
  const [repayAmount, setRepayAmount] = useState('');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['loans'],
    queryFn: () => loansApi.getMyLoans().then((r) => r.data),
  });

  const applyMutation = useMutation({
    mutationFn: () =>
      loansApi.apply({ amount: parseInt(loanForm.amount), purpose: loanForm.purpose, duration: parseInt(loanForm.duration) }),
    onSuccess: () => {
      Alert.alert('Application sent!', 'Your loan will be reviewed within 24 hours.');
      setApplyModal(false);
      queryClient.invalidateQueries({ queryKey: ['loans'] });
    },
    onError: (err: any) => Alert.alert('Error', err.response?.data?.message || 'Application failed'),
  });

  const repayMutation = useMutation({
    mutationFn: () => loansApi.repay(repayModal.id, parseFloat(repayAmount)),
    onSuccess: () => {
      Alert.alert('Payment sent!', 'Your repayment has been processed.');
      setRepayModal(null);
      queryClient.invalidateQueries({ queryKey: ['loans'] });
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
    },
    onError: (err: any) => Alert.alert('Error', err.response?.data?.message || 'Payment failed'),
  });

  const loans = data?.loans || MOCK_LOANS;
  const active = loans.filter((l: any) => l.status === 'ACTIVE');
  const history = loans.filter((l: any) => l.status !== 'ACTIVE');
  const creditScore = user?.creditScore || 680;
  const s = makeStyles(theme);

  return (
    <View style={s.container}>
      <View style={s.header}>
        <Text style={s.headerTitle}>Shamba Finance</Text>
        <Text style={s.headerSub}>Empowering farmers with credit</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} onScrollEndDrag={refetch}>
        <CreditMeter score={creditScore} theme={theme} />

        {/* Active loans */}
        {active.length > 0 && (
          <>
            <Text style={s.sectionTitle}>Active loans</Text>
            {active.map((loan: any) => (
              <LoanCard key={loan.id} loan={loan} theme={theme} onRepay={() => setRepayModal(loan)} />
            ))}
          </>
        )}

        {/* History */}
        {history.length > 0 && (
          <>
            <Text style={s.sectionTitle}>Loan history</Text>
            {history.map((loan: any) => (
              <LoanCard key={loan.id} loan={loan} theme={theme} />
            ))}
          </>
        )}

        {loans.length === 0 && !isLoading && (
          <View style={s.emptyBox}>
            <Text style={{ fontSize: 36, marginBottom: 10 }}>💰</Text>
            <Text style={s.emptyText}>No loans yet. Apply for your first loan below.</Text>
          </View>
        )}

        <TouchableOpacity style={s.applyBtn} onPress={() => setApplyModal(true)}>
          <Text style={s.applyBtnText}>Apply for a loan</Text>
        </TouchableOpacity>

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Apply modal */}
      <Modal visible={applyModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <ScrollView>
            <View style={[s.modalCard, { margin: 20 }]}>
              <Text style={s.modalTitle}>Apply for a loan</Text>

              <Text style={s.label}>Amount (KES)</Text>
              <TextInput
                style={s.modalInput}
                value={loanForm.amount}
                onChangeText={(v) => setLoanForm({ ...loanForm, amount: v })}
                placeholder="e.g. 10000"
                placeholderTextColor={theme.colors.textMuted}
                keyboardType="numeric"
              />

              <Text style={s.label}>Purpose</Text>
              <TextInput
                style={s.modalInput}
                value={loanForm.purpose}
                onChangeText={(v) => setLoanForm({ ...loanForm, purpose: v })}
                placeholder="e.g. Buy seeds and fertiliser"
                placeholderTextColor={theme.colors.textMuted}
              />

              <Text style={s.label}>Duration (months)</Text>
              <View style={{ flexDirection: 'row', gap: 8, marginBottom: 16 }}>
                {['1', '3', '6', '12'].map((m) => (
                  <TouchableOpacity
                    key={m}
                    style={[s.durationBtn, loanForm.duration === m && s.durationBtnActive]}
                    onPress={() => setLoanForm({ ...loanForm, duration: m })}
                  >
                    <Text style={[s.durationText, loanForm.duration === m && { color: '#fff' }]}>{m}mo</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {loanForm.amount ? (
                <View style={s.estimateBox}>
                  <Text style={s.estimateLabel}>Estimated monthly repayment</Text>
                  <Text style={s.estimateValue}>
                    KES {Math.round((parseInt(loanForm.amount || '0') * 1.15) / parseInt(loanForm.duration || '3')).toLocaleString()}
                  </Text>
                </View>
              ) : null}

              <View style={s.modalBtns}>
                <TouchableOpacity style={s.cancelBtn} onPress={() => setApplyModal(false)}>
                  <Text style={s.cancelBtnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={s.confirmBtn}
                  onPress={() => applyMutation.mutate()}
                  disabled={applyMutation.isPending}
                >
                  {applyMutation.isPending
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={s.confirmBtnText}>Submit</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* Repay modal */}
      <Modal visible={!!repayModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modalCard}>
            <Text style={s.modalTitle}>Make a repayment</Text>
            {repayModal && (
              <>
                <Text style={[s.label, { marginBottom: 2 }]}>{repayModal.purpose}</Text>
                <Text style={{ fontSize: 13, color: theme.colors.textSecondary, marginBottom: 14 }}>
                  Outstanding: KES {(repayModal.amount - repayModal.paid).toLocaleString()}
                </Text>
                <Text style={s.label}>Amount (KES)</Text>
                <TextInput
                  style={s.modalInput}
                  value={repayAmount}
                  onChangeText={setRepayAmount}
                  placeholder="Enter amount"
                  placeholderTextColor={theme.colors.textMuted}
                  keyboardType="numeric"
                />
                <View style={s.modalBtns}>
                  <TouchableOpacity style={s.cancelBtn} onPress={() => setRepayModal(null)}>
                    <Text style={s.cancelBtnText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={s.confirmBtn}
                    onPress={() => repayMutation.mutate()}
                    disabled={repayMutation.isPending}
                  >
                    {repayMutation.isPending
                      ? <ActivityIndicator color="#fff" />
                      : <Text style={s.confirmBtnText}>Pay</Text>
                    }
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

function LoanCard({ loan, theme, onRepay }: any) {
  const pct = Math.min((loan.paid / loan.amount) * 100, 100);
  const isActive = loan.status === 'ACTIVE';
  return (
    <View style={{ backgroundColor: theme.colors.cardBg, borderRadius: theme.radius.md, padding: 14, marginHorizontal: 14, marginBottom: 8, borderWidth: 0.5, borderColor: theme.colors.cardBorder }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 13, fontWeight: '500', color: theme.colors.textPrimary }}>{loan.purpose}</Text>
          <Text style={{ fontSize: 11, color: theme.colors.textSecondary, marginTop: 2 }}>
            KES {loan.paid?.toLocaleString()} of {loan.amount?.toLocaleString()} repaid
          </Text>
        </View>
        <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, backgroundColor: isActive ? theme.colors.successBg : '#1E1E3A' }}>
          <Text style={{ fontSize: 10, fontWeight: '600', color: isActive ? theme.colors.successText : '#9090D0' }}>
            {loan.status}
          </Text>
        </View>
      </View>
      <View style={{ height: 4, backgroundColor: theme.colors.border, borderRadius: 2, marginTop: 10 }}>
        <View style={{ height: 4, width: `${pct}%`, backgroundColor: isActive ? theme.colors.primary : '#8888CC', borderRadius: 2 }} />
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
        <Text style={{ fontSize: 10, color: theme.colors.textMuted }}>{loan.disbursedAt ? `Disbursed: ${new Date(loan.disbursedAt).toLocaleDateString()}` : ''}</Text>
        <Text style={{ fontSize: 10, color: theme.colors.textMuted }}>{loan.dueDate ? `Due: ${new Date(loan.dueDate).toLocaleDateString()}` : ''}</Text>
      </View>
      {isActive && onRepay && (
        <TouchableOpacity
          style={{ marginTop: 10, borderWidth: 0.5, borderColor: theme.colors.primary, borderRadius: 8, paddingVertical: 8, alignItems: 'center' }}
          onPress={onRepay}
        >
          <Text style={{ fontSize: 12, color: theme.colors.primary, fontWeight: '500' }}>Make repayment</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const MOCK_LOANS = [
  { id: '1', purpose: 'Agricultural Input Loan', amount: 10000, paid: 8000, status: 'ACTIVE', disbursedAt: '2025-01-15', dueDate: '2025-02-15' },
  { id: '2', purpose: 'Emergency Crop Loan', amount: 5000, paid: 5000, status: 'PAID', disbursedAt: '2024-10-05', dueDate: '2024-11-30' },
];

const makeStyles = (theme: ReturnType<typeof import('../../src/lib/theme').useTheme>) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.colors.background },
    header: { backgroundColor: theme.colors.header, padding: 16, paddingTop: 52, paddingBottom: 22 },
    headerTitle: { color: '#fff', fontSize: 18, fontWeight: '600' },
    headerSub: { color: 'rgba(255,255,255,0.65)', fontSize: 12, marginTop: 2 },
    sectionTitle: { fontSize: 13, fontWeight: '600', color: theme.colors.textPrimary, marginHorizontal: 14, marginBottom: 8, marginTop: 8 },
    emptyBox: { alignItems: 'center', padding: 32 },
    emptyText: { fontSize: 14, color: theme.colors.textSecondary, textAlign: 'center' },
    applyBtn: {
      backgroundColor: theme.colors.primary, borderRadius: theme.radius.md,
      paddingVertical: 15, marginHorizontal: 14, alignItems: 'center', marginTop: 12,
    },
    applyBtnText: { color: '#fff', fontWeight: '600', fontSize: 15 },
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' },
    modalCard: {
      backgroundColor: theme.colors.cardBg, borderTopLeftRadius: 20, borderTopRightRadius: 20,
      padding: 22, borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    modalTitle: { fontSize: 18, fontWeight: '600', color: theme.colors.textPrimary, marginBottom: 16 },
    label: { fontSize: 12, fontWeight: '500', color: theme.colors.textSecondary, marginBottom: 6 },
    modalInput: {
      backgroundColor: theme.colors.background, borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.sm, paddingHorizontal: 14, paddingVertical: 11,
      fontSize: 15, color: theme.colors.textPrimary, marginBottom: 14,
    },
    durationBtn: {
      flex: 1, paddingVertical: 8, borderRadius: 8, borderWidth: 0.5,
      borderColor: theme.colors.border, alignItems: 'center', backgroundColor: theme.colors.background,
    },
    durationBtnActive: { backgroundColor: theme.colors.primary, borderColor: theme.colors.primary },
    durationText: { fontSize: 12, fontWeight: '500', color: theme.colors.textSecondary },
    estimateBox: {
      backgroundColor: theme.colors.successBg, borderRadius: theme.radius.sm,
      padding: 12, marginBottom: 14,
    },
    estimateLabel: { fontSize: 11, color: theme.colors.successText, marginBottom: 2 },
    estimateValue: { fontSize: 18, fontWeight: '700', color: theme.colors.successText },
    modalBtns: { flexDirection: 'row', gap: 10, marginTop: 4 },
    cancelBtn: { flex: 1, borderWidth: 0.5, borderColor: theme.colors.border, borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center' },
    cancelBtnText: { fontSize: 14, color: theme.colors.textSecondary },
    confirmBtn: { flex: 1, backgroundColor: theme.colors.primary, borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center' },
    confirmBtnText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  });
