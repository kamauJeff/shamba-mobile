import { useState } from 'react';
import {
  View, Text, ScrollView, FlatList, TouchableOpacity,
  TextInput, StyleSheet, Modal, Alert, ActivityIndicator,
} from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { marketApi } from '../../src/api/client';
import { useTheme } from '../../src/lib/theme';

const CATEGORIES = ['All', 'Crops', 'Livestock', 'Inputs', 'Dairy'];

const CATEGORY_ICONS: Record<string, string> = {
  Crops: '🌾', Livestock: '🐄', Inputs: '🪣', Dairy: '🥛', Other: '📦',
};

export default function MarketScreen() {
  const theme = useTheme();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [buyModal, setBuyModal] = useState<any>(null);
  const [createModal, setCreateModal] = useState(false);
  const [quantity, setQuantity] = useState('1');

  // New listing state
  const [newListing, setNewListing] = useState({
    name: '', category: 'Crops', price: '', unit: 'kg', quantity: '', county: '',
  });

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['market', activeCategory, search],
    queryFn: () =>
      marketApi.getListings({
        category: activeCategory === 'All' ? undefined : activeCategory.toUpperCase(),
        search: search || undefined,
      }).then((r) => r.data),
  });

  const buyMutation = useMutation({
    mutationFn: ({ id, qty }: { id: string; qty: number }) => marketApi.buy(id, qty),
    onSuccess: () => {
      Alert.alert('Success', 'Purchase confirmed!');
      setBuyModal(null);
      queryClient.invalidateQueries({ queryKey: ['market'] });
      queryClient.invalidateQueries({ queryKey: ['wallet'] });
    },
    onError: (err: any) => Alert.alert('Error', err.response?.data?.message || 'Purchase failed'),
  });

  const createMutation = useMutation({
    mutationFn: () => marketApi.createListing(newListing),
    onSuccess: () => {
      Alert.alert('Listed!', 'Your listing is now live.');
      setCreateModal(false);
      queryClient.invalidateQueries({ queryKey: ['market'] });
    },
    onError: (err: any) => Alert.alert('Error', err.response?.data?.message || 'Could not create listing'),
  });

  const listings = data?.listings || [];
  const s = makeStyles(theme);

  return (
    <View style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <Text style={s.headerTitle}>Shamba Market</Text>
          <TouchableOpacity style={s.createBtn} onPress={() => setCreateModal(true)}>
            <Text style={s.createBtnText}>+ Sell</Text>
          </TouchableOpacity>
        </View>
        <View style={s.searchBar}>
          <Text style={{ fontSize: 16, marginRight: 8 }}>🔍</Text>
          <TextInput
            style={s.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="Search crops, livestock..."
            placeholderTextColor="rgba(255,255,255,0.5)"
          />
        </View>
      </View>

      {/* Category tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.tabsScroll} contentContainerStyle={s.tabsContainer}>
        {CATEGORIES.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[s.tab, activeCategory === cat && s.tabActive]}
            onPress={() => setActiveCategory(cat)}
          >
            <Text style={[s.tabText, activeCategory === cat && s.tabTextActive]}>{cat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Listings */}
      {isLoading ? (
        <ActivityIndicator color={theme.colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={listings.length > 0 ? listings : MOCK_LISTINGS}
          keyExtractor={(item) => item.id}
          contentContainerStyle={s.list}
          showsVerticalScrollIndicator={false}
          onRefresh={refetch}
          refreshing={false}
          renderItem={({ item }) => (
            <View style={s.listingCard}>
              <View style={s.listingImg}>
                <Text style={{ fontSize: 28 }}>{CATEGORY_ICONS[item.category] || '📦'}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.listingName}>{item.name}</Text>
                <Text style={s.listingMeta}>{item.county} · {item.quantity} {item.unit} available</Text>
                <Text style={s.listingPrice}>KES {item.price} / {item.unit}</Text>
              </View>
              <TouchableOpacity style={s.buyBtn} onPress={() => setBuyModal(item)}>
                <Text style={s.buyBtnText}>Buy</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}

      {/* Buy modal */}
      <Modal visible={!!buyModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modalCard}>
            <Text style={s.modalTitle}>Confirm purchase</Text>
            {buyModal && (
              <>
                <Text style={s.modalItem}>{buyModal.name}</Text>
                <Text style={s.modalMeta}>KES {buyModal.price} / {buyModal.unit}</Text>
                <Text style={s.label}>Quantity ({buyModal.unit})</Text>
                <TextInput
                  style={s.modalInput}
                  value={quantity}
                  onChangeText={setQuantity}
                  keyboardType="numeric"
                />
                <Text style={s.modalTotal}>
                  Total: KES {(buyModal.price * parseInt(quantity || '0')).toLocaleString()}
                </Text>
                <View style={s.modalBtns}>
                  <TouchableOpacity style={s.cancelBtn} onPress={() => setBuyModal(null)}>
                    <Text style={s.cancelBtnText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={s.confirmBtn}
                    onPress={() => buyMutation.mutate({ id: buyModal.id, qty: parseInt(quantity) })}
                    disabled={buyMutation.isPending}
                  >
                    {buyMutation.isPending
                      ? <ActivityIndicator color="#fff" />
                      : <Text style={s.confirmBtnText}>Confirm</Text>
                    }
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Create listing modal */}
      <Modal visible={createModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <ScrollView>
            <View style={[s.modalCard, { margin: 20 }]}>
              <Text style={s.modalTitle}>New listing</Text>
              {[
                { key: 'name', label: 'Product name', placeholder: 'e.g. Maize Grade A' },
                { key: 'price', label: 'Price per unit (KES)', placeholder: '0', type: 'numeric' },
                { key: 'unit', label: 'Unit', placeholder: 'kg / litre / head' },
                { key: 'quantity', label: 'Quantity', placeholder: '100', type: 'numeric' },
                { key: 'county', label: 'County', placeholder: 'Nakuru' },
              ].map((field) => (
                <View key={field.key} style={{ marginBottom: 12 }}>
                  <Text style={s.label}>{field.label}</Text>
                  <TextInput
                    style={s.modalInput}
                    value={(newListing as any)[field.key]}
                    onChangeText={(v) => setNewListing({ ...newListing, [field.key]: v })}
                    placeholder={field.placeholder}
                    placeholderTextColor={theme.colors.textMuted}
                    keyboardType={field.type === 'numeric' ? 'numeric' : 'default'}
                  />
                </View>
              ))}
              <View style={s.modalBtns}>
                <TouchableOpacity style={s.cancelBtn} onPress={() => setCreateModal(false)}>
                  <Text style={s.cancelBtnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={s.confirmBtn}
                  onPress={() => createMutation.mutate()}
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={s.confirmBtnText}>List it</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const MOCK_LISTINGS = [
  { id: '1', name: 'Maize — Grade A', category: 'Crops', county: 'Nakuru', quantity: 500, unit: 'kg', price: 42 },
  { id: '2', name: 'Fresh Milk', category: 'Dairy', county: 'Kiambu', quantity: 200, unit: 'litre', price: 55 },
  { id: '3', name: 'Tomatoes (Truss)', category: 'Crops', county: 'Meru', quantity: 300, unit: 'kg', price: 80 },
  { id: '4', name: 'Onions (Red)', category: 'Crops', county: 'Kajiado', quantity: 150, unit: 'kg', price: 65 },
  { id: '5', name: 'Kienyeji Chicken', category: 'Livestock', county: 'Machakos', quantity: 40, unit: 'bird', price: 650 },
  { id: '6', name: 'DAP Fertiliser', category: 'Inputs', county: 'Nakuru', quantity: 50, unit: 'bag', price: 3800 },
];

const makeStyles = (theme: ReturnType<typeof import('../../src/lib/theme').useTheme>) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.colors.background },

    header: { backgroundColor: theme.colors.header, padding: 16, paddingTop: 52, paddingBottom: 20 },
    headerTitle: { color: '#fff', fontSize: 18, fontWeight: '600' },
    createBtn: {
      backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 20,
      paddingHorizontal: 14, paddingVertical: 6,
    },
    createBtnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    searchBar: {
      flexDirection: 'row', alignItems: 'center',
      backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10,
    },
    searchInput: { flex: 1, color: '#fff', fontSize: 14 },

    tabsScroll: { backgroundColor: theme.colors.cardBg, borderBottomWidth: 0.5, borderBottomColor: theme.colors.border },
    tabsContainer: { paddingHorizontal: 12, paddingVertical: 10, gap: 8 },
    tab: {
      paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20,
      borderWidth: 0.5, borderColor: theme.colors.border, backgroundColor: theme.colors.background,
    },
    tabActive: { backgroundColor: theme.colors.primary, borderColor: theme.colors.primary },
    tabText: { fontSize: 12, color: theme.colors.textSecondary, fontWeight: '500' },
    tabTextActive: { color: '#fff' },

    list: { padding: 14, gap: 10 },
    listingCard: {
      backgroundColor: theme.colors.cardBg, borderRadius: theme.radius.md,
      padding: 13, flexDirection: 'row', alignItems: 'center', gap: 12,
      borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    listingImg: {
      width: 56, height: 56, borderRadius: 10,
      backgroundColor: theme.colors.primaryLight, alignItems: 'center', justifyContent: 'center',
    },
    listingName: { fontSize: 13, fontWeight: '500', color: theme.colors.textPrimary },
    listingMeta: { fontSize: 11, color: theme.colors.textSecondary, marginTop: 2 },
    listingPrice: { fontSize: 14, fontWeight: '600', color: theme.colors.primary, marginTop: 4 },
    buyBtn: { backgroundColor: theme.colors.primary, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 8 },
    buyBtnText: { color: '#fff', fontSize: 12, fontWeight: '600' },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
    modalCard: {
      backgroundColor: theme.colors.cardBg, borderTopLeftRadius: 20, borderTopRightRadius: 20,
      padding: 22, borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    modalTitle: { fontSize: 18, fontWeight: '600', color: theme.colors.textPrimary, marginBottom: 14 },
    modalItem: { fontSize: 15, fontWeight: '500', color: theme.colors.textPrimary },
    modalMeta: { fontSize: 13, color: theme.colors.textSecondary, marginBottom: 14 },
    label: { fontSize: 12, fontWeight: '500', color: theme.colors.textSecondary, marginBottom: 6 },
    modalInput: {
      backgroundColor: theme.colors.background, borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.sm, paddingHorizontal: 14, paddingVertical: 11,
      fontSize: 15, color: theme.colors.textPrimary, marginBottom: 10,
    },
    modalTotal: { fontSize: 16, fontWeight: '700', color: theme.colors.textPrimary, marginVertical: 10 },
    modalBtns: { flexDirection: 'row', gap: 10, marginTop: 8 },
    cancelBtn: {
      flex: 1, borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center',
    },
    cancelBtnText: { fontSize: 14, color: theme.colors.textSecondary },
    confirmBtn: {
      flex: 1, backgroundColor: theme.colors.primary,
      borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center',
    },
    confirmBtnText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  });
