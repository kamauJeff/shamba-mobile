import { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Alert, Modal, TextInput, ActivityIndicator, Switch,
  useColorScheme,
} from 'react-native';
import { router } from 'expo-router';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '../../src/store/auth.store';
import { farmerApi } from '../../src/api/client';
import { useTheme } from '../../src/lib/theme';

const COUNTIES = [
  'Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Kiambu', 'Machakos',
  'Meru', 'Kirinyaga', 'Nyeri', 'Uasin Gishu', 'Trans Nzoia',
  'Kajiado', 'Nandi', 'Laikipia', 'Other',
];

function Avatar({ name, size = 64, theme }: { name: string; size?: number; theme: any }) {
  const initials = name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase();
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2,
      backgroundColor: 'rgba(255,255,255,0.2)',
      alignItems: 'center', justifyContent: 'center',
    }}>
      <Text style={{ fontSize: size * 0.35, color: '#fff', fontWeight: '600' }}>{initials}</Text>
    </View>
  );
}

function RowItem({ icon, label, value, onPress, danger, theme }: any) {
  return (
    <TouchableOpacity
      style={{
        flexDirection: 'row', alignItems: 'center', gap: 13,
        paddingHorizontal: 16, paddingVertical: 14,
        borderBottomWidth: 0.5, borderBottomColor: theme.colors.border,
      }}
      onPress={onPress}
      disabled={!onPress}
      activeOpacity={onPress ? 0.6 : 1}
    >
      <Text style={{ fontSize: 18, width: 24, textAlign: 'center' }}>{icon}</Text>
      <Text style={{ flex: 1, fontSize: 14, color: danger ? theme.colors.danger : theme.colors.textPrimary }}>
        {label}
      </Text>
      {value && <Text style={{ fontSize: 13, color: theme.colors.textSecondary }}>{value}</Text>}
      {onPress && <Text style={{ fontSize: 16, color: theme.colors.textMuted }}>›</Text>}
    </TouchableOpacity>
  );
}

export default function ProfileScreen() {
  const theme = useTheme();
  const colorScheme = useColorScheme();
  const queryClient = useQueryClient();
  const { user, updateUser, logout } = useAuthStore();

  const [editModal, setEditModal] = useState(false);
  const [form, setForm] = useState({
    name: user?.name || '',
    county: user?.county || '',
    farmSize: user?.farmSize?.toString() || '',
  });
  const [countyPicker, setCountyPicker] = useState(false);

  const updateMutation = useMutation({
    mutationFn: () =>
      farmerApi.update(user!.id, {
        name: form.name,
        county: form.county,
        farmSize: parseFloat(form.farmSize) || undefined,
      }),
    onSuccess: (res) => {
      updateUser(res.data);
      setEditModal(false);
      Alert.alert('Saved', 'Profile updated successfully.');
    },
    onError: (err: any) => Alert.alert('Error', err.response?.data?.message || 'Update failed'),
  });

  const handleLogout = () => {
    Alert.alert('Log out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: () => {
          logout();
          queryClient.clear();
          router.replace('/(auth)/login');
        },
      },
    ]);
  };

  const creditTier =
    (user?.creditScore || 0) >= 750 ? 'Excellent' :
    (user?.creditScore || 0) >= 670 ? 'Good' :
    (user?.creditScore || 0) >= 580 ? 'Fair' : 'Poor';

  const s = makeStyles(theme);

  return (
    <View style={s.container}>
      {/* Header */}
      <View style={s.header}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Avatar name={user?.name || 'JK'} theme={theme} />
          <TouchableOpacity style={s.editBtn} onPress={() => setEditModal(true)}>
            <Text style={s.editBtnText}>Edit</Text>
          </TouchableOpacity>
        </View>
        <Text style={s.userName}>{user?.name || 'Farmer'}</Text>
        <Text style={s.userRole}>
          {user?.role === 'FARMER' ? '🌾' : '🛒'} {user?.role?.charAt(0) + (user?.role?.slice(1).toLowerCase() || '')} · {user?.county || 'Kenya'}
        </Text>
        <Text style={s.userPhone}>{user?.phone}</Text>

        {/* Score pill */}
        <View style={s.scorePill}>
          <Text style={s.scorePillText}>
            ⭐ Credit score: {user?.creditScore || '—'} ({creditTier})
          </Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Wallet summary */}
        <View style={s.walletRow}>
          <View style={s.walletItem}>
            <Text style={s.walletLabel}>Wallet balance</Text>
            <Text style={s.walletValue}>KES {(user?.walletBalance || 0).toLocaleString()}</Text>
          </View>
          <View style={[s.walletItem, { borderLeftWidth: 0.5, borderLeftColor: theme.colors.border }]}>
            <Text style={s.walletLabel}>Member since</Text>
            <Text style={s.walletValue}>
              {user?.memberSince
                ? new Date(user.memberSince).toLocaleDateString('en-KE', { month: 'short', year: 'numeric' })
                : 'Jan 2024'}
            </Text>
          </View>
        </View>

        {/* Farm info */}
        <Text style={s.sectionTitle}>Farm details</Text>
        <View style={s.section}>
          <RowItem icon="📍" label="County" value={user?.county || '—'} theme={theme} />
          <RowItem icon="🌿" label="Farm size" value={user?.farmSize ? `${user.farmSize} acres` : '—'} theme={theme} />
          <RowItem icon="🛡️" label="Insurance" value="Active · Crop cover" theme={theme} />
          <RowItem icon="💳" label="Shamba Pay" value="Linked" theme={theme} />
        </View>

        {/* App settings */}
        <Text style={s.sectionTitle}>App</Text>
        <View style={s.section}>
          <RowItem icon="🌙" label={`Appearance: ${colorScheme === 'dark' ? 'Dark' : 'Light'} mode`} theme={theme} value="System" />
          <RowItem
            icon="🔔"
            label="Notifications"
            theme={theme}
            value="On"
            onPress={() => Alert.alert('Coming soon', 'Notification settings will be available soon.')}
          />
          <RowItem
            icon="🌍"
            label="Language"
            theme={theme}
            value="English"
            onPress={() => Alert.alert('Coming soon', 'Swahili and other languages coming soon.')}
          />
        </View>

        {/* Support */}
        <Text style={s.sectionTitle}>Support</Text>
        <View style={s.section}>
          <RowItem
            icon="❓"
            label="Help & FAQ"
            theme={theme}
            onPress={() => Alert.alert('Help', 'Visit shamba.tech/help or call +254 700 000 000')}
          />
          <RowItem
            icon="📞"
            label="Contact support"
            theme={theme}
            onPress={() => Alert.alert('Support', 'support@shamba.tech\n+254 700 000 000')}
          />
          <RowItem
            icon="📋"
            label="Terms of service"
            theme={theme}
            onPress={() => Alert.alert('Terms', 'Visit shamba.tech/terms')}
          />
          <View style={{ borderBottomWidth: 0 }}>
            <RowItem
              icon="🔒"
              label="Privacy policy"
              theme={theme}
              onPress={() => Alert.alert('Privacy', 'Visit shamba.tech/privacy')}
            />
          </View>
        </View>

        {/* Danger zone */}
        <View style={[s.section, { marginTop: 8 }]}>
          <RowItem icon="🚪" label="Log out" theme={theme} onPress={handleLogout} danger />
        </View>

        <Text style={s.versionText}>Shamba v1.0.0 · Made with ❤️ in Kenya</Text>
        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Edit profile modal */}
      <Modal visible={editModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <ScrollView>
            <View style={[s.modalCard, { margin: 20 }]}>
              <Text style={s.modalTitle}>Edit profile</Text>

              <Text style={s.label}>Full name</Text>
              <TextInput
                style={s.input}
                value={form.name}
                onChangeText={(v) => setForm({ ...form, name: v })}
                placeholder="Your name"
                placeholderTextColor={theme.colors.textMuted}
                autoCapitalize="words"
              />

              <Text style={s.label}>County</Text>
              <TouchableOpacity
                style={[s.input, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}
                onPress={() => setCountyPicker(!countyPicker)}
              >
                <Text style={{ color: form.county ? theme.colors.textPrimary : theme.colors.textMuted, fontSize: 15 }}>
                  {form.county || 'Select county'}
                </Text>
                <Text style={{ color: theme.colors.textMuted }}>▼</Text>
              </TouchableOpacity>
              {countyPicker && (
                <View style={s.dropdown}>
                  {COUNTIES.map((c) => (
                    <TouchableOpacity
                      key={c}
                      style={[s.dropdownItem, form.county === c && { backgroundColor: theme.colors.primaryLight }]}
                      onPress={() => { setForm({ ...form, county: c }); setCountyPicker(false); }}
                    >
                      <Text style={{ fontSize: 14, color: form.county === c ? theme.colors.primary : theme.colors.textPrimary }}>
                        {c}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              <Text style={s.label}>Farm size (acres)</Text>
              <TextInput
                style={s.input}
                value={form.farmSize}
                onChangeText={(v) => setForm({ ...form, farmSize: v })}
                placeholder="e.g. 2.5"
                placeholderTextColor={theme.colors.textMuted}
                keyboardType="decimal-pad"
              />

              <View style={s.modalBtns}>
                <TouchableOpacity style={s.cancelBtn} onPress={() => setEditModal(false)}>
                  <Text style={s.cancelBtnText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={s.saveBtn}
                  onPress={() => updateMutation.mutate()}
                  disabled={updateMutation.isPending}
                >
                  {updateMutation.isPending
                    ? <ActivityIndicator color="#fff" />
                    : <Text style={s.saveBtnText}>Save changes</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const makeStyles = (theme: ReturnType<typeof import('../../src/lib/theme').useTheme>) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.colors.background },

    header: { backgroundColor: theme.colors.header, padding: 20, paddingTop: 52, paddingBottom: 24 },
    editBtn: {
      backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 20,
      paddingHorizontal: 14, paddingVertical: 6,
    },
    editBtnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    userName: { color: '#fff', fontSize: 20, fontWeight: '700', marginTop: 12, letterSpacing: -0.3 },
    userRole: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginTop: 3 },
    userPhone: { color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 },
    scorePill: {
      alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.15)',
      borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5, marginTop: 10,
    },
    scorePillText: { color: '#fff', fontSize: 12, fontWeight: '500' },

    walletRow: {
      flexDirection: 'row', backgroundColor: theme.colors.cardBg,
      borderBottomWidth: 0.5, borderBottomColor: theme.colors.border,
    },
    walletItem: { flex: 1, padding: 16 },
    walletLabel: { fontSize: 11, color: theme.colors.textSecondary, marginBottom: 4 },
    walletValue: { fontSize: 16, fontWeight: '600', color: theme.colors.textPrimary },

    sectionTitle: {
      fontSize: 12, fontWeight: '600', color: theme.colors.textSecondary,
      marginHorizontal: 16, marginTop: 18, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5,
    },
    section: {
      backgroundColor: theme.colors.cardBg,
      borderTopWidth: 0.5, borderBottomWidth: 0.5,
      borderColor: theme.colors.border,
    },

    versionText: { textAlign: 'center', fontSize: 11, color: theme.colors.textMuted, marginTop: 16 },

    // Modal
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' },
    modalCard: {
      backgroundColor: theme.colors.cardBg,
      borderTopLeftRadius: 20, borderTopRightRadius: 20,
      padding: 22, borderWidth: 0.5, borderColor: theme.colors.cardBorder,
    },
    modalTitle: { fontSize: 18, fontWeight: '600', color: theme.colors.textPrimary, marginBottom: 18 },
    label: { fontSize: 12, fontWeight: '500', color: theme.colors.textSecondary, marginBottom: 6 },
    input: {
      backgroundColor: theme.colors.background, borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.sm, paddingHorizontal: 14, paddingVertical: 12,
      fontSize: 15, color: theme.colors.textPrimary, marginBottom: 14,
    },
    dropdown: {
      borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.sm, backgroundColor: theme.colors.cardBg,
      marginBottom: 14, maxHeight: 200,
    },
    dropdownItem: {
      paddingHorizontal: 14, paddingVertical: 11,
      borderBottomWidth: 0.5, borderBottomColor: theme.colors.border,
    },
    modalBtns: { flexDirection: 'row', gap: 10, marginTop: 4 },
    cancelBtn: {
      flex: 1, borderWidth: 0.5, borderColor: theme.colors.border,
      borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center',
    },
    cancelBtnText: { fontSize: 14, color: theme.colors.textSecondary },
    saveBtn: { flex: 1, backgroundColor: theme.colors.primary, borderRadius: theme.radius.md, paddingVertical: 13, alignItems: 'center' },
    saveBtnText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  });
