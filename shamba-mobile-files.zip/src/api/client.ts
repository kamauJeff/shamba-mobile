import axios, { AxiosInstance, InternalAxiosRequestConfig, AxiosResponse } from 'axios';
import { useAuthStore } from '../store/auth.store';

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://192.168.0.104:3000/api/v1';

const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach token to every request
apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = useAuthStore.getState().token;
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Handle 401 — attempt refresh
apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      const refreshToken = useAuthStore.getState().refreshToken;
      if (refreshToken) {
        try {
          const res = await axios.post(`${BASE_URL}/auth/refresh`, { refreshToken });
          const { token } = res.data;
          useAuthStore.getState().setToken(token);
          original.headers.Authorization = `Bearer ${token}`;
          return apiClient(original);
        } catch {
          useAuthStore.getState().logout();
        }
      } else {
        useAuthStore.getState().logout();
      }
    }
    return Promise.reject(error);
  }
);

// ─── Auth ─────────────────────────────────────────────────────────────────
export const authApi = {
  login: (phone: string, password: string) =>
    apiClient.post('/auth/login', { phone, password }),
  register: (data: { name: string; phone: string; password: string; role: string; county?: string }) =>
    apiClient.post('/auth/register', data),
  refresh: (refreshToken: string) =>
    apiClient.post('/auth/refresh', { refreshToken }),
  me: () => apiClient.get('/auth/me'),
};

// ─── Farmer ───────────────────────────────────────────────────────────────
export const farmerApi = {
  getProfile: (id: string) => apiClient.get(`/farmers/${id}`),
  update: (id: string, data: object) => apiClient.patch(`/farmers/${id}`, data),
  getCreditScore: (id: string) => apiClient.get(`/farmers/${id}/credit-score`),
};

// ─── Loans ────────────────────────────────────────────────────────────────
export const loansApi = {
  getMyLoans: () => apiClient.get('/loans/my'),
  apply: (data: { amount: number; purpose: string; duration: number }) =>
    apiClient.post('/loans/apply', data),
  repay: (loanId: string, amount: number) =>
    apiClient.post(`/loans/${loanId}/repay`, { amount }),
  getById: (id: string) => apiClient.get(`/loans/${id}`),
};

// ─── Market ───────────────────────────────────────────────────────────────
export const marketApi = {
  getListings: (params?: { category?: string; county?: string; search?: string }) =>
    apiClient.get('/market', { params }),
  createListing: (data: object) => apiClient.post('/market', data),
  buy: (listingId: string, quantity: number) =>
    apiClient.post(`/market/${listingId}/buy`, { quantity }),
};

// ─── Wallet ───────────────────────────────────────────────────────────────
export const walletApi = {
  getBalance: () => apiClient.get('/wallet/balance'),
  getTransactions: () => apiClient.get('/wallet/transactions'),
  send: (to: string, amount: number) => apiClient.post('/wallet/send', { to, amount }),
  deposit: (amount: number) => apiClient.post('/wallet/deposit', { amount }),
};

// ─── Groups ───────────────────────────────────────────────────────────────
export const groupsApi = {
  getGroups: () => apiClient.get('/groups'),
  getMyGroups: () => apiClient.get('/groups/my'),
  join: (groupId: string) => apiClient.post(`/groups/${groupId}/join`),
  leave: (groupId: string) => apiClient.post(`/groups/${groupId}/leave`),
};

// ─── Weather ──────────────────────────────────────────────────────────────
export const weatherApi = {
  getCurrent: (county: string) => apiClient.get(`/weather?county=${county}`),
  getForecast: (county: string) => apiClient.get(`/weather/forecast?county=${county}`),
};

// ─── Insurance ────────────────────────────────────────────────────────────
export const insuranceApi = {
  getMyPolicies: () => apiClient.get('/insurance/my'),
  enroll: (data: object) => apiClient.post('/insurance/enroll', data),
};

export default apiClient;
